<?php
/**
 * Featured Galleries Block
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Featured Galleries Block
 */
function register_featured_galleries_block() {
    // Register the block
    register_block_type('andykemp/featured-galleries', array(
        'attributes' => array(
            'title' => array(
                'type' => 'string',
                'default' => 'Latest Galleries'
            ),
            'subtitle' => array(
                'type' => 'string',
                'default' => 'Discover my most recent photographic work'
            ),
            'numberOfGalleries' => array(
                'type' => 'number',
                'default' => 3
            ),
            'parentPage' => array(
                'type' => 'number',
                'default' => 0
            ),
            'showButton' => array(
                'type' => 'boolean',
                'default' => true
            ),
            'buttonText' => array(
                'type' => 'string',
                'default' => 'View All Galleries'
            ),
            'buttonUrl' => array(
                'type' => 'string',
                'default' => ''
            )
        ),
        'render_callback' => 'render_featured_galleries_block'
    ));
}
add_action('init', 'register_featured_galleries_block');

/**
 * Render Featured Galleries Block
 */
function render_featured_galleries_block($attributes) {
    $title = $attributes['title'] ?? 'Latest Galleries';
    $subtitle = $attributes['subtitle'] ?? 'Discover my most recent photographic work';
    $number = $attributes['numberOfGalleries'] ?? 3;
    $parent_page = $attributes['parentPage'] ?? 0;
    $show_button = $attributes['showButton'] ?? true;
    $button_text = $attributes['buttonText'] ?? 'View All Galleries';
    $button_url = $attributes['buttonUrl'] ?? home_url('/galleries/');

    ob_start();
    ?>
    
    <div class="wp-block-andykemp-featured-galleries">
        <main id="primary" class="main-content">
            <article class="content-section">
                <div class="page-content" style="padding: 60px 40px;">
                    
                    <?php if ($title || $subtitle) : ?>
                    <header class="page-header">
                        <?php if ($title) : ?>
                        <h1 class="page-title"><?php echo esc_html($title); ?></h1>
                        <?php endif; ?>
                        
                        <?php if ($subtitle) : ?>
                        <div class="page-intro">
                            <p><?php echo esc_html($subtitle); ?></p>
                        </div>
                        <?php endif; ?>
                    </header>
                    <?php endif; ?>

                    <div class="featured-galleries">
                    <?php
                    // EXACT COPY of page-galleries.php query, just with custom parent and limit
                    $galleries_query = new WP_Query(array(
                        'post_type' => 'page',
                        'post_parent' => $parent_page,
                        'posts_per_page' => $number, // Only difference - limit the number
                        'orderby' => 'modified', // Show most recently updated first
                        'order' => 'DESC',
                        'post_status' => 'publish'
                    ));

                    if ($galleries_query->have_posts()) :
                        while ($galleries_query->have_posts()) : $galleries_query->the_post(); ?>
                            <div class="gallery-card">
                                <a href="<?php the_permalink(); ?>" class="gallery-card-link">
                                    <div class="gallery-card-image">
                                        <?php if (has_post_thumbnail()) : ?>
                                            <?php the_post_thumbnail('large', array('class' => 'gallery-thumbnail-img')); ?>
                                        <?php else : ?>
                                            <div class="gallery-card-placeholder">
                                                <i class="fas fa-camera"></i>
                                                <span>No Image</span>
                                            </div>
                                        <?php endif; ?>
                                    </div>
                                    <div class="gallery-card-content">
                                        <h3 class="gallery-card-title"><?php the_title(); ?></h3>
                                        <?php if (has_excerpt()) : ?>
                                            <p class="gallery-card-description"><?php echo get_the_excerpt(); ?></p>
                                        <?php else : ?>
                                            <p class="gallery-card-description">Explore this collection of photographs.</p>
                                        <?php endif; ?>
                                    </div>
                                </a>
                            </div>
                        <?php endwhile;
                        wp_reset_postdata();
                    else : ?>
                        <div class="no-galleries">
                            <h3>Getting Started</h3>
                            <p>To display your photo galleries here, create new pages and set this page as their parent.</p>
                            <div class="setup-instructions">
                                <h4>Quick Setup:</h4>
                                <ol>
                                    <li>Go to <strong>Pages → Add New</strong></li>
                                    <li>Create pages like "Landscapes", "Portraits", "Street Photography"</li>
                                    <li>In <strong>Page Attributes</strong>, set <strong>Parent</strong> to your main galleries page</li>
                                    <li>Set a <strong>Featured Image</strong> for each gallery</li>
                                    <li>Publish the pages</li>
                                </ol>
                                <p>Your galleries will automatically appear here!</p>
                            </div>
                        </div>
                    <?php endif; ?>
                    </div>
                    
                    <?php if ($show_button && $button_text && $button_url && $galleries_query->have_posts()) : ?>
                    <div style="text-align: center; margin-top: 2rem;">
                        <a href="<?php echo esc_url($button_url); ?>" class="btn btn-primary"><?php echo esc_html($button_text); ?></a>
                    </div>
                    <?php endif; ?>
                </div>
            </article>
        </main>
    </div>
    
    <?php
    return ob_get_clean();
}

/**
 * Enqueue Block Editor Assets
 */
function featured_galleries_block_editor_assets() {
    wp_enqueue_script(
        'featured-galleries-block',
        get_template_directory_uri() . '/assets/js/featured-galleries-block.js',
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n'),
        '1.0.0',
        true
    );

    // Localize script with pages data for parent page selection
    $pages = get_pages(array('sort_column' => 'post_title'));
    $pages_data = array();
    $pages_data[] = array('value' => 0, 'label' => 'All pages (auto-detect galleries)');
    
    foreach ($pages as $page) {
        $pages_data[] = array(
            'value' => $page->ID,
            'label' => $page->post_title
        );
    }
    
    wp_localize_script('featured-galleries-block', 'featuredGalleriesData', array(
        'pages' => $pages_data
    ));
}
add_action('enqueue_block_editor_assets', 'featured_galleries_block_editor_assets');