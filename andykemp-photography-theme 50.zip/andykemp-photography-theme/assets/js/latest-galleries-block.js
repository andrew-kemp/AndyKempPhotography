(function(blocks, element, editor, components, i18n) {
    var el = element.createElement;
    var registerBlockType = blocks.registerBlockType;
    var InspectorControls = editor.InspectorControls;
    var PanelBody = components.PanelBody;
    var PanelRow = components.PanelRow;
    var TextControl = components.TextControl;
    var TextareaControl = components.TextareaControl;
    var RangeControl = components.RangeControl;
    var SelectControl = components.SelectControl;
    var ToggleControl = components.ToggleControl;
    var __ = i18n.__;

    registerBlockType('andykemp/latest-galleries', {
        title: __('Latest Galleries', 'andykemp-photography'),
        description: __('Display your latest gallery pages with customizable title and options.', 'andykemp-photography'),
        icon: 'format-gallery',
        category: 'widgets',
        attributes: {
            title: {
                type: 'string',
                default: 'Latest Galleries'
            },
            subtitle: {
                type: 'string',
                default: 'Discover my most recent photographic work'
            },
            numberOfGalleries: {
                type: 'number',
                default: 3
            },
            parentPage: {
                type: 'number',
                default: 0
            },
            showButton: {
                type: 'boolean',
                default: true
            },
            buttonText: {
                type: 'string',
                default: 'View All Galleries'
            },
            buttonUrl: {
                type: 'string',
                default: ''
            }
        },

        edit: function(props) {
            var attributes = props.attributes;
            var setAttributes = props.setAttributes;

            // Get pages data from localized script
            var pages = window.latestGalleriesData ? window.latestGalleriesData.pages : [];

            return [
                el(InspectorControls, { key: 'inspector' },
                    el(PanelBody, { title: __('Content Settings', 'andykemp-photography'), initialOpen: true },
                        el(TextControl, {
                            label: __('Title', 'andykemp-photography'),
                            value: attributes.title,
                            onChange: function(value) {
                                setAttributes({ title: value });
                            }
                        }),
                        el(TextareaControl, {
                            label: __('Subtitle', 'andykemp-photography'),
                            value: attributes.subtitle,
                            onChange: function(value) {
                                setAttributes({ subtitle: value });
                            }
                        })
                    ),
                    el(PanelBody, { title: __('Gallery Settings', 'andykemp-photography'), initialOpen: true },
                        el(RangeControl, {
                            label: __('Number of Galleries', 'andykemp-photography'),
                            value: attributes.numberOfGalleries,
                            onChange: function(value) {
                                setAttributes({ numberOfGalleries: value });
                            },
                            min: 1,
                            max: 12
                        }),
                        el(SelectControl, {
                            label: __('Parent Page', 'andykemp-photography'),
                            value: attributes.parentPage,
                            options: pages,
                            onChange: function(value) {
                                setAttributes({ parentPage: parseInt(value) });
                            }
                        })
                    ),
                    el(PanelBody, { title: __('Button Settings', 'andykemp-photography'), initialOpen: false },
                        el(ToggleControl, {
                            label: __('Show Button', 'andykemp-photography'),
                            checked: attributes.showButton,
                            onChange: function(value) {
                                setAttributes({ showButton: value });
                            }
                        }),
                        attributes.showButton && el(TextControl, {
                            label: __('Button Text', 'andykemp-photography'),
                            value: attributes.buttonText,
                            onChange: function(value) {
                                setAttributes({ buttonText: value });
                            }
                        }),
                        attributes.showButton && el(TextControl, {
                            label: __('Button URL', 'andykemp-photography'),
                            value: attributes.buttonUrl,
                            onChange: function(value) {
                                setAttributes({ buttonUrl: value });
                            }
                        })
                    )
                ),
                el('div', { 
                    key: 'preview',
                    className: 'latest-galleries-block-preview',
                    style: { 
                        padding: '20px', 
                        border: '1px solid #e2e4e7', 
                        borderRadius: '4px',
                        background: '#f8f9fa'
                    } 
                },
                    el('h3', { 
                        style: { 
                            margin: '0 0 10px 0',
                            fontSize: '1.2em',
                            color: '#1e1e1e'
                        } 
                    }, attributes.title || 'Latest Galleries'),
                    el('p', { 
                        style: { 
                            margin: '0 0 15px 0',
                            color: '#757575',
                            fontSize: '0.9em'
                        } 
                    }, attributes.subtitle || 'Discover my most recent photographic work'),
                    el('div', {
                        style: {
                            display: 'grid',
                            gridTemplateColumns: 'repeat(auto-fit, minmax(150px, 1fr))',
                            gap: '10px',
                            marginBottom: '15px'
                        }
                    },
                        Array.from({ length: Math.min(attributes.numberOfGalleries, 3) }, function(_, i) {
                            return el('div', {
                                key: i,
                                style: {
                                    height: '100px',
                                    background: '#ddd',
                                    borderRadius: '8px',
                                    display: 'flex',
                                    alignItems: 'center',
                                    justifyContent: 'center',
                                    color: '#666',
                                    fontSize: '0.8em'
                                }
                            }, 'Gallery ' + (i + 1));
                        })
                    ),
                    el('p', { 
                        style: { 
                            margin: '0',
                            fontSize: '0.8em',
                            color: '#666',
                            fontStyle: 'italic'
                        } 
                    }, __('Showing ' + attributes.numberOfGalleries + ' galleries from selected parent page', 'andykemp-photography'))
                )
            ];
        },

        save: function() {
            // Server-side rendering, return null
            return null;
        }
    });

})(
    window.wp.blocks,
    window.wp.element,
    window.wp.editor,
    window.wp.components,
    window.wp.i18n
);