<?php
/**
 * Template part for displaying latest galleries section
 */

$latest_galleries = andykemp_photography_get_latest_galleries(3);

if (!empty($latest_galleries)) : ?>

<section class="latest-galleries">
    <div class="container">
        <h2>Latest Galleries</h2>
        <p class="section-subtitle">Discover my most recent photographic work</p>
        
        <div class="galleries-grid">
            <?php foreach ($latest_galleries as $gallery) : 
                $gallery_url = get_permalink($gallery->ID);
                $gallery_title = get_the_title($gallery->ID);
                $gallery_excerpt = get_the_excerpt($gallery->ID);
                $featured_image_url = get_the_post_thumbnail_url($gallery->ID, 'portfolio-large');
                
                // Fallback excerpt if none exists
                if (empty($gallery_excerpt)) {
                    $content = wp_trim_words(strip_tags($gallery->post_content), 20, '...');
                    $gallery_excerpt = !empty($content) ? $content : 'Explore this stunning collection of photographs.';
                }
            ?>
            
            <article class="gallery-card">
                <a href="<?php echo esc_url($gallery_url); ?>" class="gallery-card-link">
                    <?php if ($featured_image_url) : ?>
                    <div class="gallery-card-image">
                        <img src="<?php echo esc_url($featured_image_url); ?>" 
                             alt="<?php echo esc_attr($gallery_title); ?>" 
                             loading="lazy">
                        <div class="gallery-card-overlay">
                            <span class="view-gallery">View Gallery</span>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <div class="gallery-card-content">
                        <h3 class="gallery-card-title"><?php echo esc_html($gallery_title); ?></h3>
                        <p class="gallery-card-excerpt"><?php echo esc_html($gallery_excerpt); ?></p>
                        <span class="gallery-card-date">Updated: <?php echo get_the_modified_date('M j, Y', $gallery->ID); ?></span>
                    </div>
                </a>
            </article>
            
            <?php endforeach; ?>
        </div>
        
        <div class="galleries-cta">
            <a href="<?php echo esc_url(home_url('/galleries/')); ?>" class="btn btn-primary">View All Galleries</a>
        </div>
    </div>
</section>

<?php else : ?>

<!-- Fallback if no galleries found -->
<section class="latest-galleries">
    <div class="container">
        <h2>Latest Galleries</h2>
        <p class="section-subtitle">Gallery setup in progress</p>
        
        <div class="gallery-setup-notice">
            <h3>Getting Started with Galleries</h3>
            <p>To display your latest galleries here:</p>
            <ol>
                <li>Create new pages for each gallery collection</li>
                <li>Add featured images to each gallery page</li>
                <li>Add excerpts describing each collection</li>
                <li>Your 3 most recently updated galleries will automatically appear here</li>
            </ol>
            <a href="<?php echo admin_url('edit.php?post_type=page'); ?>" class="btn btn-primary">Create Gallery Pages</a>
        </div>
    </div>
</section>

<?php endif; ?>