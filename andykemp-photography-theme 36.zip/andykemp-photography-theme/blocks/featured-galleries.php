<?php
/**
 * Featured Galleries Block
 */

// Prevent direct access
if (!defined('ABSPATH')) {
    exit;
}

/**
 * Register Featured Galleries Block
 */
function register_featured_galleries_block() {
    // Register the block
    register_block_type('andykemp/featured-galleries', array(
        'attributes' => array(
            'title' => array(
                'type' => 'string',
                'default' => 'Latest Galleries'
            ),
            'subtitle' => array(
                'type' => 'string',
                'default' => 'Discover my most recent photographic work'
            ),
            'numberOfGalleries' => array(
                'type' => 'number',
                'default' => 3
            ),
            'parentPage' => array(
                'type' => 'number',
                'default' => 0
            ),
            'showButton' => array(
                'type' => 'boolean',
                'default' => true
            ),
            'buttonText' => array(
                'type' => 'string',
                'default' => 'View All Galleries'
            ),
            'buttonUrl' => array(
                'type' => 'string',
                'default' => ''
            )
        ),
        'render_callback' => 'render_featured_galleries_block'
    ));
}
add_action('init', 'register_featured_galleries_block');

/**
 * Render Featured Galleries Block
 */
function render_featured_galleries_block($attributes) {
    $title = $attributes['title'] ?? 'Latest Galleries';
    $subtitle = $attributes['subtitle'] ?? 'Discover my most recent photographic work';
    $number = $attributes['numberOfGalleries'] ?? 3;
    $parent_page = $attributes['parentPage'] ?? 0;
    $show_button = $attributes['showButton'] ?? true;
    $button_text = $attributes['buttonText'] ?? 'View All Galleries';
    $button_url = $attributes['buttonUrl'] ?? home_url('/galleries/');

    // Get galleries
    $latest_galleries = andykemp_photography_get_latest_galleries($number, $parent_page);

    ob_start();
    ?>
    
    <div class="wp-block-andykemp-featured-galleries">
        <?php if (!empty($latest_galleries)) : ?>
        
        <div class="latest-galleries-widget">
            <div class="container">
                <?php if ($title) : ?>
                <h2><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
                
                <?php if ($subtitle) : ?>
                <p class="section-subtitle"><?php echo esc_html($subtitle); ?></p>
                <?php endif; ?>
                
                <div class="galleries-grid">
                    <?php foreach ($latest_galleries as $gallery) : 
                        $gallery_url = get_permalink($gallery->ID);
                        $gallery_title = get_the_title($gallery->ID);
                        $gallery_excerpt = get_the_excerpt($gallery->ID);
                        $featured_image_url = get_the_post_thumbnail_url($gallery->ID, 'portfolio-large');
                        
                        // Fallback excerpt if none exists
                        if (empty($gallery_excerpt)) {
                            $content = wp_trim_words(strip_tags($gallery->post_content), 20, '...');
                            $gallery_excerpt = !empty($content) ? $content : 'Explore this stunning collection of photographs.';
                        }
                    ?>
                    
                    <article class="gallery-card">
                        <a href="<?php echo esc_url($gallery_url); ?>" class="gallery-card-link">
                            <div class="gallery-card-image">
                                <?php if ($featured_image_url) : ?>
                                    <img src="<?php echo esc_url($featured_image_url); ?>" 
                                         alt="<?php echo esc_attr($gallery_title); ?>" 
                                         class="gallery-thumbnail-img"
                                         loading="lazy">
                                <?php else : ?>
                                    <div class="gallery-card-placeholder">
                                        <i class="fas fa-camera"></i>
                                        <span>No Image</span>
                                    </div>
                                <?php endif; ?>
                            </div>
                            
                            <div class="gallery-card-content">
                                <h3 class="gallery-card-title"><?php echo esc_html($gallery_title); ?></h3>
                                <?php if (!empty($gallery_excerpt)) : ?>
                                    <p class="gallery-card-description"><?php echo esc_html($gallery_excerpt); ?></p>
                                <?php else : ?>
                                    <p class="gallery-card-description">Explore this collection of photographs.</p>
                                <?php endif; ?>
                            </div>
                        </a>
                    </article>
                    
                    <?php endforeach; ?>
                </div>
                
                <?php if ($show_button && $button_text && $button_url) : ?>
                <div class="galleries-cta">
                    <a href="<?php echo esc_url($button_url); ?>" class="btn btn-primary"><?php echo esc_html($button_text); ?></a>
                </div>
                <?php endif; ?>
            </div>
        </div>

        <?php else : ?>

        <!-- Fallback if no galleries found -->
        <div class="latest-galleries-widget">
            <div class="container">
                <?php if ($title) : ?>
                <h2><?php echo esc_html($title); ?></h2>
                <?php endif; ?>
                
                <p class="section-subtitle">Gallery setup in progress</p>
                
                <div class="gallery-setup-notice">
                    <h3>Getting Started with Galleries</h3>
                    <p>To display your latest galleries here:</p>
                    <ol>
                        <li>Create new pages for each gallery collection</li>
                        <li>Add featured images to each gallery page</li>
                        <li>Add excerpts describing each collection</li>
                        <li>Your most recently updated galleries will automatically appear here</li>
                    </ol>
                    <a href="<?php echo admin_url('edit.php?post_type=page'); ?>" class="btn btn-primary">Create Gallery Pages</a>
                </div>
            </div>
        </div>

        <?php endif; ?>
    </div>
    
    <?php
    return ob_get_clean();
}

/**
 * Enqueue Block Editor Assets
 */
function featured_galleries_block_editor_assets() {
    wp_enqueue_script(
        'featured-galleries-block',
        get_template_directory_uri() . '/assets/js/featured-galleries-block.js',
        array('wp-blocks', 'wp-element', 'wp-editor', 'wp-components', 'wp-i18n'),
        '1.0.0',
        true
    );

    // Localize script with pages data for parent page selection
    $pages = get_pages(array('sort_column' => 'post_title'));
    $pages_data = array();
    $pages_data[] = array('value' => 0, 'label' => 'All pages (auto-detect galleries)');
    
    foreach ($pages as $page) {
        $pages_data[] = array(
            'value' => $page->ID,
            'label' => $page->post_title
        );
    }
    
    wp_localize_script('featured-galleries-block', 'featuredGalleriesData', array(
        'pages' => $pages_data
    ));
}
add_action('enqueue_block_editor_assets', 'featured_galleries_block_editor_assets');